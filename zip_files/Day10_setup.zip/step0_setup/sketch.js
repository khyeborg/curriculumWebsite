function setup() {
   createCanvas(windowWidth, windowHeight);
   noStroke();
   noiseDetail(24);
}
 
function draw() {
   background(0);
}